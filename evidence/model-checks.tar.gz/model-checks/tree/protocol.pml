/* Generated from this template by scripts/check_models.py.
 * Two durable SQLite-style slots; one proctype for each registered worker.
 * A slot is retained after ack, matching UNIQUE(run,id) retention.
 * Atomic transitions are individual Store BEGIN IMMEDIATE transactions.
 * Faults occur BETWEEN transactions. No network reliability claim is made.
 */
#define AGENTS 4
#define MESSAGES 2
#ifndef CAPACITY
#define CAPACITY 2
#endif

byte sender[MESSAGES];
byte recipient[MESSAGES];
byte content[MESSAGES];
bool allowed[AGENTS * AGENTS];
bool accepted[MESSAGES];
bool received[MESSAGES];
bool acknowledged[MESSAGES];
bool local_receipt[MESSAGES];
bool redelivered[MESSAGES];
bool lost_ack[MESSAGES];
bool restarted[MESSAGES];
bool full_rejected[MESSAGES];
byte occupancy[AGENTS];
byte stored = 0;

inline invariant(m) {
    assert(stored <= MESSAGES);
    assert(occupancy[recipient[m]] <= CAPACITY);
    assert(!accepted[m] || allowed[sender[m] * AGENTS + recipient[m]]);
    assert(!accepted[m] || content[m] == m);
    assert(!received[m] || accepted[m]);
    assert(!acknowledged[m] || received[m]);
}

/* The scheduler chooses both participant and enabled transaction. Every
 * fault/duplicate action is bounded, so none can postpone an ack forever.
 */
proctype Agent(byte actor) {
    do

    :: atomic { actor == sender[0] && !accepted[0] && occupancy[recipient[0]] < CAPACITY ->
#ifdef BUG_ALLOW_FORBIDDEN
         recipient[0] = actor;
#endif
         assert(allowed[actor * AGENTS + recipient[0]]);
         assert(stored < MESSAGES);
         accepted[0] = true; content[0] = 0; stored++; occupancy[recipient[0]]++;
         printf("EVENT send 0 %d %d\n", actor, recipient[0]); invariant(0);
         /* These calls stutter: no persistent state changes, so their placement
          * is abstracted to this transaction boundary. Runtime tests exercise
          * independently scheduled duplicate and rejected calls. */
         printf("EVENT duplicate 0\n"); invariant(0);
         printf("EVENT reject_collision 0\n"); invariant(0);
         printf("EVENT reject_early_ack 0\n");
#ifdef BUG_EARLY_ACK
         acknowledged[0] = true;
#endif
         invariant(0) }
    :: atomic { actor == sender[0] && !accepted[0] && occupancy[recipient[0]] >= CAPACITY && !full_rejected[0] ->
         full_rejected[0] = true;
         printf("EVENT reject_full 0\n"); invariant(0) }
    :: atomic { actor == recipient[0] && accepted[0] && !received[0] ->
         received[0] = true; local_receipt[0] = true;
         printf("EVENT receive 0 %d\n", actor); invariant(0) }
    :: atomic { actor == recipient[0] && received[0] && !acknowledged[0] && !redelivered[0] ->
         redelivered[0] = true; local_receipt[0] = true;
         printf("EVENT redeliver 0\n"); invariant(0) }
    :: atomic { actor == recipient[0] && received[0] && !acknowledged[0] && !lost_ack[0] ->
         lost_ack[0] = true;
         /* One ack invocation is lost BEFORE its database transaction. */
         printf("EVENT lost_ack 0\n"); invariant(0) }
    :: atomic { actor == recipient[0] && received[0] && !acknowledged[0] && !restarted[0] ->
         restarted[0] = true; local_receipt[0] = false;
         /* Durable received flag survives restart; only caller memory is lost. */
         printf("EVENT restart 0\n"); invariant(0) }
    :: atomic { (actor == recipient[0] && received[0] && !acknowledged[0]
#ifdef BUG_NO_ACK
         && 0 != 0
#endif
         ) -> acknowledged[0] = true; occupancy[recipient[0]]--;
         printf("EVENT ack 0 %d\n", actor); invariant(0) }


    :: atomic { actor == sender[1] && !accepted[1] && occupancy[recipient[1]] < CAPACITY ->
#ifdef BUG_ALLOW_FORBIDDEN
         recipient[1] = actor;
#endif
         assert(allowed[actor * AGENTS + recipient[1]]);
         assert(stored < MESSAGES);
         accepted[1] = true; content[1] = 1; stored++; occupancy[recipient[1]]++;
         printf("EVENT send 1 %d %d\n", actor, recipient[1]); invariant(1);
         /* These calls stutter: no persistent state changes, so their placement
          * is abstracted to this transaction boundary. Runtime tests exercise
          * independently scheduled duplicate and rejected calls. */
         printf("EVENT duplicate 1\n"); invariant(1);
         printf("EVENT reject_collision 1\n"); invariant(1);
         printf("EVENT reject_early_ack 1\n");
#ifdef BUG_EARLY_ACK
         acknowledged[1] = true;
#endif
         invariant(1) }
    :: atomic { actor == sender[1] && !accepted[1] && occupancy[recipient[1]] >= CAPACITY && !full_rejected[1] ->
         full_rejected[1] = true;
         printf("EVENT reject_full 1\n"); invariant(1) }
    :: atomic { actor == recipient[1] && accepted[1] && !received[1] ->
         received[1] = true; local_receipt[1] = true;
         printf("EVENT receive 1 %d\n", actor); invariant(1) }
    :: atomic { actor == recipient[1] && received[1] && !acknowledged[1] && !redelivered[1] ->
         redelivered[1] = true; local_receipt[1] = true;
         printf("EVENT redeliver 1\n"); invariant(1) }
    :: atomic { actor == recipient[1] && received[1] && !acknowledged[1] && !lost_ack[1] ->
         lost_ack[1] = true;
         /* One ack invocation is lost BEFORE its database transaction. */
         printf("EVENT lost_ack 1\n"); invariant(1) }
    :: atomic { actor == recipient[1] && received[1] && !acknowledged[1] && !restarted[1] ->
         restarted[1] = true; local_receipt[1] = false;
         /* Durable received flag survives restart; only caller memory is lost. */
         printf("EVENT restart 1\n"); invariant(1) }
    :: atomic { (actor == recipient[1] && received[1] && !acknowledged[1]
#ifdef BUG_NO_ACK
         && 1 != 0
#endif
         ) -> acknowledged[1] = true; occupancy[recipient[1]]--;
         printf("EVENT ack 1 %d\n", actor); invariant(1) }

    :: acknowledged[0] && acknowledged[1] -> break
    od
}

#ifdef BUG_NO_ACK
/* A permanently unresponsive receiver is outside the bounded-fault contract.
 * Keep an infinite execution so LTL detects starvation independently of
 * invalid-end-state checks. This is an isolated negative control. */
active proctype PermanentStall() { do :: true -> skip od }
#endif

init {
    atomic {
        allowed[0 * AGENTS + 1] = true;
        allowed[1 * AGENTS + 0] = true;
        allowed[1 * AGENTS + 2] = true;
        allowed[1 * AGENTS + 3] = true;
        allowed[2 * AGENTS + 1] = true;
        allowed[3 * AGENTS + 1] = true;
        if
        :: sender[0] = 0; recipient[0] = 1
        :: sender[0] = 1; recipient[0] = 0
        :: sender[0] = 1; recipient[0] = 2
        :: sender[0] = 1; recipient[0] = 3
        :: sender[0] = 2; recipient[0] = 1
        :: sender[0] = 3; recipient[0] = 1
        fi;
        if
        :: sender[1] = 0; recipient[1] = 1
        :: sender[1] = 1; recipient[1] = 0
        :: sender[1] = 1; recipient[1] = 2
        :: sender[1] = 1; recipient[1] = 3
        :: sender[1] = 2; recipient[1] = 1
        :: sender[1] = 3; recipient[1] = 1
        fi;
        run Agent(0);
        run Agent(1);
        run Agent(2);
        run Agent(3);
    }
}

ltl message_0_progress { [] (accepted[0] -> <> acknowledged[0]) }
ltl message_1_progress { [] (accepted[1] -> <> acknowledged[1]) }
